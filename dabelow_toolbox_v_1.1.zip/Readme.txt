*****************************************************
 DabelowToolBox_v1.0.ms

 12.25.09
Aaron Dabelow, theonlyaaron@gmail.com
 www.aarondabelow.com
 Written for MAX v.9.0 and up
*****************************************************
 PURPOSE:A collection of tools and macros to improve
	workflow.
*****************************************************
 HISTORY:
    - v1.0 (12.25.09):
        (i) 1stversion.
*****************************************************
*****************************************************
To Use:
	Copy the "DTB" folder to your '3ds Max\Scripts'
	directory for the tool box to find all of its 
	files.

	To startup with the toolbox place
	'dabelow_toolbox_v_1.0.ms' in your 
	'3ds Max\Scripts\Startup' directory. It will
	still be able to find all of its referenced 
	files.

	Run the max script in 3ds Max v.9.0 and up.
*****************************************************